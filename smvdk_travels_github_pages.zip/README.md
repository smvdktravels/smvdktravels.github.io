# SMVDK Travels website

This is a static, mobile-friendly website for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub repository (for example `smvdk-travels`).
2. Upload `index.html` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub to publish the site. Your URL will look like `https://YOUR-USERNAME.github.io/smvdk-travels/`.

## Before publishing
Verify all package prices, claims, office address, timings, phone number, and booking/payment policies. The booking form opens WhatsApp to +91 8493814143; it does not take payments or store customer data.
